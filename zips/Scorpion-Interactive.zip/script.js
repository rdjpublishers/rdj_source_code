/* ====================================================================
   Scorpion Cursor
   --------------------------------------------------------------------
   - The pointer (mouse / finger) is the scorpion's PREY: it turns,
     scuttles toward it and stops a claw's length away.
   - Two pedipalp arms (2-bone IK) reach out and pinch around the
     pointer; the pincers open wider when it runs and snap now and then.
   - 8 legs use a two-bone IK solver and an alternating gait; every
     footfall leaves a faint glowing print in the sand.
   - The segmented tail is a spring chain. It sways, lifts when the
     scorpion speeds up, swings opposite to turns -- and CLICK / TAP
     makes it wind up and sting, with sparks, a shockwave and a shake.
   - Left alone, it wanders and stings on its own.
   - Rendered as a neon-amber wireframe using canvas shadowBlur glow.
==================================================================== */

(() => {
  'use strict';

  const TAU = Math.PI * 2;

  /* ------------------------------------------------------------------
     Configuration
  ------------------------------------------------------------------- */
  const COLOR_RGB = [255, 178, 62];     // amber body glow
  const STING_RGB = [255, 59, 47];      // hot red stinger
  const FLASH_RGB = [255, 241, 207];    // white-hot flash on impact
  const DUST_RGB  = [240, 207, 154];    // sand
  const BODY_FILL = '#1b100a';          // dark plate fill (hides what is underneath)
  const GLOW_BLUR = 12;                 // CSS-pixel glow radius

  // Movement
  const STOP_DIST  = 82;     // how far from the pointer the head settles
  const MAX_SPEED  = 640;    // px/s at full sprint
  const SPEED_GAIN = 5;      // how strongly distance turns into speed
  const TURN_GAIN  = 10;     // how eagerly it turns toward the pointer
  const MAX_TURN   = 7.5;    // rad/s
  const IDLE_MS    = 7000;   // no input for this long -> wander on its own

  // Body spine (head/carapace -> 5 mesosoma plates), before scaling
  const SPINE   = [22, 15, 15, 14, 13];
  const SEG_R   = [13.5, 13, 11.5, 10, 8.5];   // plate half-widths
  const CARAPACE_RX = 18;
  const CARAPACE_RY = 13.5;

  // Tail (metasoma)
  const TAIL_SEG  = 17;
  const TAIL_R    = [7.4, 7, 6.4, 5.8, 5, 4.3, 3.8];
  // Resting curl in (back, side) units: a hook that curls round beside the body
  const TAIL_REST = [[12, 0], [26, 5], [38, 16], [42, 32], [34, 46], [20, 50], [7, 44]];
  const TAIL_N    = TAIL_R.length;
  const STING_LEN = 17;
  const STRIKE_DUR = 0.72;   // seconds for a complete sting

  // Pedipalp arms + pincers
  const ARM1 = 34;
  const ARM2 = 36;
  const SNAP_TIME = 0.2;

  // Legs, ordered front -> back
  const LEG_PAIRS = 4;
  const LEG_HIP_T = [-0.10, 0.25, 0.60, 0.95];  // hip position along head -> first plate
  const LEG_ANGLE = [42, 78, 112, 142];          // degrees away from heading
  const LEG_SCALE = [0.95, 1.02, 1.08, 1.12];
  const BONE1 = 26;
  const BONE2 = 36;
  const REACH_FACTOR = 0.82;
  const STEP_TRIGGER = 0.30;
  const STEP_TIME = 0.12;
  const STEP_LEAD = 0.14;

  const MAX_FX = 450;

  /* ------------------------------------------------------------------
     Canvas setup
  ------------------------------------------------------------------- */
  const canvas = document.getElementById('scorpion-canvas');
  const ctx = canvas.getContext('2d');
  const hint = document.getElementById('hint');

  // Pre-rendered night-sand background (grain + vignette), rebuilt on resize
  const bgCanvas = document.createElement('canvas');

  let width = 0;
  let height = 0;
  let dpr = 1;
  let scale = 1;

  function resize() {
    dpr = window.devicePixelRatio || 1;
    width = window.innerWidth;
    height = window.innerHeight;

    canvas.width = Math.round(width * dpr);
    canvas.height = Math.round(height * dpr);
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';

    scale = Math.min(1.2, Math.max(0.62, Math.min(width, height) / 760));
    buildBackground();
  }

  function buildBackground() {
    bgCanvas.width = canvas.width;
    bgCanvas.height = canvas.height;
    const b = bgCanvas.getContext('2d');
    b.setTransform(dpr, 0, 0, dpr, 0, 0);

    const g = b.createRadialGradient(width / 2, height / 2, 0, width / 2, height / 2, Math.hypot(width, height) * 0.62);
    g.addColorStop(0, '#1c1210');
    g.addColorStop(0.55, '#100a0d');
    g.addColorStop(1, '#050308');
    b.fillStyle = g;
    b.fillRect(0, 0, width, height);

    // Sand grains: tiny faint specks
    const count = Math.min(1600, Math.round((width * height) / 1500));
    for (let i = 0; i < count; i++) {
      const a = 0.03 + Math.random() * 0.09;
      b.fillStyle = `rgba(${DUST_RGB[0]},${DUST_RGB[1]},${DUST_RGB[2]},${a})`;
      b.beginPath();
      b.arc(Math.random() * width, Math.random() * height, 0.4 + Math.random() * 0.9, 0, TAU);
      b.fill();
    }
  }

  /* ------------------------------------------------------------------
     Small helpers
  ------------------------------------------------------------------- */
  const lerp = (a, b, t) => a + (b - a) * t;
  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
  const smoothstep = (t) => t * t * (3 - 2 * t);
  const dist = (ax, ay, bx, by) => Math.hypot(bx - ax, by - ay);
  const rgba = (c, a) => `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${a})`;
  const mixRGB = (c1, c2, t) => [lerp(c1[0], c2[0], t), lerp(c1[1], c2[1], t), lerp(c1[2], c2[2], t)];
  function angleDiff(a, b) {
    let d = a - b;
    while (d > Math.PI) d -= TAU;
    while (d < -Math.PI) d += TAU;
    return d;
  }

  /* ------------------------------------------------------------------
     State
  ------------------------------------------------------------------- */
  const pointer = { x: 0, y: 0, active: false, lastInput: 0 };
  const head = { x: 0, y: 0, heading: 0, speed: 0, angVel: 0, vx: 0, vy: 0 };
  const spine = [];   // mesosoma plate centres
  const tail = [];    // tail node positions

  let curl = 1;        // which side the tail curls to (-1 .. 1), eased
  let curlTarget = 1;
  let shake = 0;
  let nextAutoStrike = 0;

  const strike = { t: -1, px: 0, py: 0, hit: false, env: 0, side: 1 };

  const legs = [];
  for (let i = 0; i < LEG_PAIRS; i++) {
    for (const side of [-1, 1]) {
      legs.push({
        index: i,
        side,
        group: (i + (side === 1 ? 0 : 1)) % 2,   // diagonal legs step together
        foot: { x: 0, y: 0 },
        stepping: false,
        stepT: 0,
        from: { x: 0, y: 0 },
        to: { x: 0, y: 0 },
        initialised: false,
      });
    }
  }

  const claws = [-1, 1].map((side) => ({
    side,
    wrist: { x: 0, y: 0 },
    elbow: { x: 0, y: 0 },
    shoulder: { x: 0, y: 0 },
    f: { x: 1, y: 0 },
    open: 0.4,
    snapT: -1,
    nextSnap: 0.8 + (side === 1 ? 0.7 : 0),
    initialised: false,
  }));

  const fx = [];   // particles: prints, dust, rings, sparks

  function init() {
    head.x = width / 2;
    head.y = height / 2;
    head.heading = 0;

    let x = head.x;
    for (let i = 0; i < SPINE.length; i++) {
      x -= SPINE[i] * scale;
      spine.push({ x, y: head.y });
    }
    for (let i = 0; i < TAIL_N; i++) {
      x -= TAIL_SEG * scale;
      tail.push({ x, y: head.y });
    }

    pointer.x = width / 2 + 120 * scale;
    pointer.y = height / 2;
    pointer.lastInput = performance.now();
    nextAutoStrike = performance.now() + 3500;
  }

  /* ------------------------------------------------------------------
     Particles
  ------------------------------------------------------------------- */
  function addFx(p) {
    if (fx.length >= MAX_FX) fx.shift();
    p.age = 0;
    fx.push(p);
  }

  function spawnRing(x, y, maxR, rgb, life) {
    addFx({ type: 'ring', layer: 'under', x, y, maxR, rgb, life });
  }

  function spawnDust(x, y, n, speed) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * TAU;
      const s = speed * (0.35 + Math.random() * 0.65);
      addFx({
        type: 'dust', layer: 'under', x, y,
        vx: Math.cos(a) * s, vy: Math.sin(a) * s,
        drag: 4, life: 0.45 + Math.random() * 0.4,
        size: (1.4 + Math.random() * 1.6) * scale,
      });
    }
  }

  function spawnSparks(x, y, n) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * TAU;
      const s = 140 + Math.random() * 300;
      addFx({
        type: 'spark', layer: 'over', x, y,
        vx: Math.cos(a) * s, vy: Math.sin(a) * s,
        drag: 3.2, life: 0.35 + Math.random() * 0.4,
      });
    }
  }

  function updateFx(dt) {
    for (let i = fx.length - 1; i >= 0; i--) {
      const p = fx[i];
      p.age += dt;
      if (p.age >= p.life) { fx.splice(i, 1); continue; }
      if (p.vx !== undefined) {
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        const damp = Math.exp(-p.drag * dt);
        p.vx *= damp;
        p.vy *= damp;
      }
    }
  }

  function drawFx(layer) {
    ctx.shadowBlur = 0;
    for (const p of fx) {
      if (p.layer !== layer) continue;
      const u = p.age / p.life;
      switch (p.type) {
        case 'print': {
          ctx.fillStyle = rgba(COLOR_RGB, Math.pow(1 - u, 1.5) * 0.5);
          ctx.beginPath();
          ctx.arc(p.x, p.y, 1.7 * scale, 0, TAU);
          ctx.fill();
          break;
        }
        case 'dust': {
          ctx.fillStyle = rgba(DUST_RGB, (1 - u) * 0.5);
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * (1 + u * 0.8), 0, TAU);
          ctx.fill();
          break;
        }
        case 'ring': {
          const e = 1 - Math.pow(1 - u, 3);
          ctx.strokeStyle = rgba(p.rgb, (1 - u) * 0.8);
          ctx.lineWidth = 0.6 + 2.2 * (1 - u);
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.maxR * e, 0, TAU);
          ctx.stroke();
          break;
        }
        case 'spark': {
          const c = mixRGB(FLASH_RGB, STING_RGB, u);
          ctx.strokeStyle = rgba(c, 1 - u);
          ctx.shadowColor = rgba(STING_RGB, 1);
          ctx.shadowBlur = 8 * dpr;
          ctx.lineWidth = 1.6;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x - p.vx * 0.045, p.y - p.vy * 0.045);
          ctx.stroke();
          ctx.shadowBlur = 0;
          break;
        }
      }
    }
  }

  /* ------------------------------------------------------------------
     Input (mouse + touch + pen via pointer events)
  ------------------------------------------------------------------- */
  function setPointer(x, y) {
    pointer.x = x;
    pointer.y = y;
    pointer.active = true;
    pointer.lastInput = performance.now();
  }

  window.addEventListener('pointermove', (e) => setPointer(e.clientX, e.clientY));

  canvas.addEventListener('pointerdown', (e) => {
    setPointer(e.clientX, e.clientY);
    startStrike(e.clientX, e.clientY);
    if (hint) hint.classList.add('is-hidden');
  });

  // Hide the hint on its own after a while
  setTimeout(() => { if (hint) hint.classList.add('is-hidden'); }, 10000);

  // Block touch gestures / context menu so the page never scrolls or zooms
  document.addEventListener('touchmove', (e) => e.preventDefault(), { passive: false });
  document.addEventListener('gesturestart', (e) => e.preventDefault());
  window.addEventListener('contextmenu', (e) => e.preventDefault());

  window.addEventListener('resize', resize);
  window.addEventListener('orientationchange', resize);

  /* ------------------------------------------------------------------
     Physics: body
  ------------------------------------------------------------------- */
  function constrain(parent, child, length) {
    const dx = child.x - parent.x;
    const dy = child.y - parent.y;
    const d = Math.hypot(dx, dy) || 0.0001;
    child.x = parent.x + (dx / d) * length;
    child.y = parent.y + (dy / d) * length;
  }

  function updateBody(dt, time) {
    // Nobody around? Wander on our own path.
    if (pointer.active && time - pointer.lastInput > IDLE_MS) pointer.active = false;
    if (!pointer.active) {
      const t = time * 0.0005;
      const tx = width / 2 + Math.cos(t * 1.3) * width * 0.32;
      const ty = height / 2 + Math.sin(t * 1.9) * height * 0.28;
      const k = 1 - Math.exp(-3 * dt);
      pointer.x += (tx - pointer.x) * k;
      pointer.y += (ty - pointer.y) * k;

      if (time > nextAutoStrike) {
        startStrike(pointer.x, pointer.y);
        nextAutoStrike = time + 4000 + Math.random() * 5000;
      }
    }

    const dx = pointer.x - head.x;
    const dy = pointer.y - head.y;
    const d = Math.hypot(dx, dy);
    const stop = STOP_DIST * scale;

    // Turn toward the pointer with a limited turn rate
    const desired = Math.atan2(dy, dx);
    const diff = angleDiff(desired, head.heading);
    const calm = d < stop * 0.5 ? 0.35 : 1;
    const turn = clamp(diff * TURN_GAIN * calm, -MAX_TURN, MAX_TURN);
    head.angVel += (turn - head.angVel) * (1 - Math.exp(-12 * dt));
    head.heading += head.angVel * dt;

    // Run when far, stop a claw's length away; slow down in sharp turns
    const over = d - stop;
    const align = Math.max(0, Math.cos(diff));
    const targetSpeed = over > 0
      ? Math.min(MAX_SPEED * scale, over * SPEED_GAIN) * (0.25 + 0.75 * align)
      : 0;
    head.speed += (targetSpeed - head.speed) * (1 - Math.exp(-8 * dt));

    head.vx = Math.cos(head.heading) * head.speed;
    head.vy = Math.sin(head.heading) * head.speed;
    head.x += head.vx * dt;
    head.y += head.vy * dt;

    // Each plate follows the one in front at a fixed distance
    constrain(head, spine[0], SPINE[0] * scale);
    for (let i = 1; i < spine.length; i++) {
      constrain(spine[i - 1], spine[i], SPINE[i] * scale);
    }

    shake *= Math.exp(-14 * dt);
  }

  /* ------------------------------------------------------------------
     Physics: pedipalp arms + pincers
  ------------------------------------------------------------------- */
  function updateClaws(dt, time) {
    const fx_ = Math.cos(head.heading);
    const fy_ = Math.sin(head.heading);
    const nx = -fy_;
    const ny = fx_;
    const maxW = (ARM1 + ARM2) * 0.9 * scale;
    const dHead = dist(head.x, head.y, pointer.x, pointer.y);
    const nearLimit = maxW * 1.0;
    const farLimit = maxW * 1.8;
    const w = smoothstep(clamp((farLimit - dHead) / (farLimit - nearLimit), 0, 1)); // 1 = pointer in reach
    const speedN = clamp(head.speed / (MAX_SPEED * scale), 0, 1);

    for (const c of claws) {
      const sh = c.shoulder;
      sh.x = head.x + fx_ * 9 * scale + nx * c.side * 8 * scale;
      sh.y = head.y + fy_ * 9 * scale + ny * c.side * 8 * scale;

      // Where the wrist wants to be: around the pointer when near, spread forward when far
      const pTx = pointer.x - fx_ * 8 * scale + nx * c.side * 13 * scale;
      const pTy = pointer.y - fy_ * 8 * scale + ny * c.side * 13 * scale;
      const ra = head.heading + c.side * 0.42;
      const rTx = sh.x + Math.cos(ra) * maxW * 0.85;
      const rTy = sh.y + Math.sin(ra) * maxW * 0.85;
      const tx = lerp(rTx, pTx, w);
      const ty = lerp(rTy, pTy, w) + Math.sin(time * 0.003 + c.side) * 0.8 * scale;

      if (!c.initialised) {
        c.wrist.x = tx;
        c.wrist.y = ty;
        c.initialised = true;
      }
      const k = 1 - Math.exp(-20 * dt);
      c.wrist.x += (tx - c.wrist.x) * k;
      c.wrist.y += (ty - c.wrist.y) * k;

      // Keep the wrist within reach of the shoulder
      const wd = dist(sh.x, sh.y, c.wrist.x, c.wrist.y);
      const lim = (ARM1 + ARM2) * 0.99 * scale;
      if (wd > lim) {
        c.wrist.x = sh.x + ((c.wrist.x - sh.x) / wd) * lim;
        c.wrist.y = sh.y + ((c.wrist.y - sh.y) / wd) * lim;
      }

      // Elbow bows outward (away from a point on the inner side of the body)
      const inner = { x: sh.x - nx * c.side * 60 * scale, y: sh.y - ny * c.side * 60 * scale };
      c.elbow = solveKnee(sh, c.wrist, ARM1 * scale, ARM2 * scale, inner);

      // Pincer aim: forearm direction, nudged toward the pointer when it is in reach
      let ax = c.wrist.x - c.elbow.x;
      let ay = c.wrist.y - c.elbow.y;
      let al = Math.hypot(ax, ay) || 1;
      ax /= al; ay /= al;
      let bx = pointer.x - c.wrist.x;
      let by = pointer.y - c.wrist.y;
      const bl = Math.hypot(bx, by);
      if (bl > 1) {
        bx /= bl; by /= bl;
        ax = lerp(ax, bx, w * 0.7);
        ay = lerp(ay, by, w * 0.7);
        al = Math.hypot(ax, ay) || 1;
        ax /= al; ay /= al;
      }
      c.f.x = ax;
      c.f.y = ay;

      // Pincer opening: wider when sprinting, occasional snaps
      let env = 0;
      if (c.snapT >= 0) {
        c.snapT += dt;
        const u = c.snapT / SNAP_TIME;
        if (u >= 1) c.snapT = -1;
        else env = Math.sin(Math.PI * u);
      } else if (time / 1000 > c.nextSnap) {
        c.snapT = 0;
        c.nextSnap = time / 1000 + 1.4 + Math.random() * 2.4;
      }
      const base = 0.36 + 0.34 * speedN + 0.1 * w;
      c.open = lerp(base, 0.03, env);
    }
  }

  /* ------------------------------------------------------------------
     Physics: legs (stepping + two-bone IK)
  ------------------------------------------------------------------- */
  function hipOf(leg) {
    const t = LEG_HIP_T[leg.index];
    return { x: lerp(head.x, spine[0].x, t), y: lerp(head.y, spine[0].y, t) };
  }

  function restOf(leg, heading) {
    const hip = hipOf(leg);
    const ang = heading + leg.side * (LEG_ANGLE[leg.index] * Math.PI / 180);
    const reach = (BONE1 + BONE2) * LEG_SCALE[leg.index] * REACH_FACTOR * scale;
    return { x: hip.x + Math.cos(ang) * reach, y: hip.y + Math.sin(ang) * reach, reach };
  }

  function footfall(x, y) {
    addFx({ type: 'print', layer: 'under', x, y, life: 1.6 });
    if (head.speed > 60) {
      addFx({
        type: 'dust', layer: 'under', x, y,
        vx: (Math.random() - 0.5) * 40, vy: (Math.random() - 0.5) * 40,
        drag: 4, life: 0.5, size: 2.2 * scale,
      });
    }
  }

  function updateLegs(dt) {
    const heading = head.heading;

    const groupBusy = [false, false];
    for (const leg of legs) if (leg.stepping) groupBusy[leg.group] = true;

    for (const leg of legs) {
      const hip = hipOf(leg);
      const rest = restOf(leg, heading);

      if (!leg.initialised) {
        leg.foot.x = rest.x;
        leg.foot.y = rest.y;
        leg.initialised = true;
      }

      if (leg.stepping) {
        leg.stepT += dt / STEP_TIME;
        if (leg.stepT >= 1) {
          leg.stepT = 1;
          leg.stepping = false;
          footfall(leg.to.x, leg.to.y);
        }
        const e = smoothstep(leg.stepT);
        leg.foot.x = lerp(leg.from.x, leg.to.x, e);
        leg.foot.y = lerp(leg.from.y, leg.to.y, e);
        continue;
      }

      const offRest = dist(leg.foot.x, leg.foot.y, rest.x, rest.y);
      const fullLen = (BONE1 + BONE2) * LEG_SCALE[leg.index] * scale;
      const overstretched = dist(hip.x, hip.y, leg.foot.x, leg.foot.y) > fullLen * 0.97;
      const otherGroupBusy = groupBusy[1 - leg.group];

      if (overstretched || (offRest > rest.reach * STEP_TRIGGER && !otherGroupBusy)) {
        leg.stepping = true;
        leg.stepT = 0;
        leg.from.x = leg.foot.x;
        leg.from.y = leg.foot.y;
        leg.to.x = rest.x + head.vx * STEP_LEAD;
        leg.to.y = rest.y + head.vy * STEP_LEAD;
        groupBusy[leg.group] = true;
      }
    }
  }

  /**
   * Two-bone IK: returns the joint position (law of cosines). Of the two
   * mirror solutions, picks the one farther from `outward`.
   */
  function solveKnee(hip, foot, l1, l2, outward) {
    const dx = foot.x - hip.x;
    const dy = foot.y - hip.y;
    const d = Math.hypot(dx, dy) || 0.0001;

    const maxD = l1 + l2 - 0.001;
    const minD = Math.abs(l1 - l2) + 0.001;
    const dc = Math.min(maxD, Math.max(minD, d));

    const ux = dx / d, uy = dy / d;
    const a = (l1 * l1 - l2 * l2 + dc * dc) / (2 * dc);
    const h = Math.sqrt(Math.max(0, l1 * l1 - a * a));

    const bx = hip.x + ux * a;
    const by = hip.y + uy * a;
    const k1 = { x: bx - uy * h, y: by + ux * h };
    const k2 = { x: bx + uy * h, y: by - ux * h };

    const d1 = dist(k1.x, k1.y, outward.x, outward.y);
    const d2 = dist(k2.x, k2.y, outward.x, outward.y);
    return d1 > d2 ? k1 : k2;
  }

  /* ------------------------------------------------------------------
     Physics: tail + sting
  ------------------------------------------------------------------- */
  function startStrike(x, y) {
    // Don't restart a sting that is still in its main motion
    if (strike.t >= 0 && strike.t < 0.5) return;
    strike.t = 0;
    strike.px = x;
    strike.py = y;
    strike.hit = false;
    strike.side = curl >= 0 ? 1 : -1;

    spawnRing(x, y, 64 * scale, COLOR_RGB, 0.7);
    spawnDust(x, y, 4, 60);
    for (const c of claws) c.snapT = 0;   // pincers snap shut in sympathy
  }

  function impact() {
    const t = tail[TAIL_N - 1];
    const q = tail[TAIL_N - 2];
    let dx = t.x - q.x;
    let dy = t.y - q.y;
    const l = Math.hypot(dx, dy) || 1;
    dx /= l; dy /= l;
    const sx = t.x + dx * STING_LEN * scale;
    const sy = t.y + dy * STING_LEN * scale;

    spawnRing(sx, sy, 46 * scale, STING_RGB, 0.55);
    spawnSparks(sx, sy, 16);
    spawnDust(sx, sy, 10, 150);
    shake = 5 * scale;
  }

  function updateTail(dt, time) {
    const last = SPINE.length - 1;
    const a = spine[last];
    const p = spine[last - 1];
    let bx = a.x - p.x;
    let by = a.y - p.y;
    const bl = Math.hypot(bx, by) || 1;
    bx /= bl; by /= bl;
    const nx = -by;
    const ny = bx;

    // Tail swings to the outside of a turn
    if (Math.abs(head.angVel) > 1.6) curlTarget = head.angVel > 0 ? 1 : -1;
    curl += (curlTarget - curl) * (1 - Math.exp(-2.2 * dt));

    // Sprinting straightens the tail a little
    const stretch = clamp(head.speed / (MAX_SPEED * scale * 0.55), 0, 1) * 0.55;

    // ---- sting timeline ----
    let windW = 0;
    let lungeW = 0;
    if (strike.t >= 0) {
      strike.t += dt;
      const t = strike.t;
      if (t >= STRIKE_DUR) {
        strike.t = -1;
        strike.env = 0;
      } else {
        if (t < 0.14) {
          windW = smoothstep(t / 0.14);
          strike.env = 0.35 * windW;
        } else if (t < 0.24) {
          const u = (t - 0.14) / 0.10;
          lungeW = 1 - Math.pow(1 - u, 3);
          windW = 1 - lungeW;
          strike.env = 0.35 + 0.65 * u;
        } else if (t < 0.40) {
          lungeW = 1;
          strike.env = 1;
        } else {
          lungeW = 1 - smoothstep((t - 0.40) / (STRIKE_DUR - 0.40));
          strike.env = lungeW;
        }
        if (!strike.hit && t >= 0.22) {
          strike.hit = true;
          impact();
        }
      }
    }

    // Direction of the sting (from the tail's base toward the target)
    let sdx = strike.px - a.x;
    let sdy = strike.py - a.y;
    const sl = Math.hypot(sdx, sdy);
    if (sl < 1) { sdx = Math.cos(head.heading); sdy = Math.sin(head.heading); }
    else { sdx /= sl; sdy /= sl; }

    const stiffBase = lerp(16, 90, lungeW);
    let prev = a;
    for (let i = 0; i < TAIL_N; i++) {
      const r = TAIL_REST[i];
      const restX = lerp(r[0], (i + 1) * TAIL_SEG * 0.97, stretch) * scale;
      const restY = r[1] * (1 - stretch) * scale;
      const wave = Math.sin(time * 0.002 + i * 0.6) * (0.8 + i * 0.55) * (1 + stretch * 2) * scale;

      let lx = restX;
      let ly = restY * curl + wave;

      // Wind-up: coil tighter and shiver
      lx = lerp(lx, lx * 0.72, windW);
      ly = lerp(ly, ly * 1.28 + Math.sin(time * 0.05) * 1.5 * scale, windW);

      const restWX = a.x + bx * lx + nx * ly;
      const restWY = a.y + by * lx + ny * ly;

      // Sting pose: a long arc thrown toward the target
      const arch = Math.sin(Math.PI * (i + 1) / (TAIL_N + 1)) * 14 * scale * strike.side;
      const stWX = a.x + sdx * (i + 1) * TAIL_SEG * scale - sdy * arch;
      const stWY = a.y + sdy * (i + 1) * TAIL_SEG * scale + sdx * arch;

      const tx = lerp(restWX, stWX, lungeW);
      const ty = lerp(restWY, stWY, lungeW);

      const node = tail[i];
      const k = 1 - Math.exp(-stiffBase * (1 - 0.45 * i / TAIL_N) * dt);
      node.x += (tx - node.x) * k;
      node.y += (ty - node.y) * k;

      constrain(prev, node, TAIL_SEG * scale);
      prev = node;
    }
  }

  /* ------------------------------------------------------------------
     Rendering
  ------------------------------------------------------------------- */
  const glowPx = () => GLOW_BLUR * dpr;

  function dot(x, y, r) {
    ctx.beginPath();
    ctx.arc(x, y, r, 0, TAU);
    ctx.fill();
  }

  /** Dark-filled, glowing-outline ellipse (a body plate). */
  function plate(x, y, rx, ry, rot) {
    ctx.beginPath();
    ctx.ellipse(x, y, rx, ry, rot, 0, TAU);
    ctx.shadowBlur = 0;
    ctx.fillStyle = BODY_FILL;
    ctx.fill();
    ctx.shadowBlur = glowPx();
    ctx.stroke();
  }

  function drawClaw(c) {
    const f = c.f;
    const px = -f.y;
    const py = f.x;
    const s = scale;
    const o = c.open;

    // Palm
    plate(c.wrist.x + f.x * 7 * s, c.wrist.y + f.y * 7 * s, 10 * s, 6.8 * s, Math.atan2(f.y, f.x));

    // Two curved fingers (blades that taper to a point)
    for (const j of [-1, 1]) {
      const sx = c.wrist.x + f.x * 13 * s + px * j * 4.5 * s;
      const sy = c.wrist.y + f.y * 13 * s + py * j * 4.5 * s;
      const cx = sx + f.x * 12 * s + px * j * (6 + o * 16) * s;
      const cy = sy + f.y * 12 * s + py * j * (6 + o * 16) * s;
      const tx = sx + f.x * 25 * s + px * j * (1.2 + o * 24) * s;
      const ty = sy + f.y * 25 * s + py * j * (1.2 + o * 24) * s;
      const s2x = sx - px * j * 3.2 * s;
      const s2y = sy - py * j * 3.2 * s;
      const c2x = cx - px * j * 5 * s;
      const c2y = cy - py * j * 5 * s;

      ctx.beginPath();
      ctx.moveTo(sx, sy);
      ctx.quadraticCurveTo(cx, cy, tx, ty);
      ctx.quadraticCurveTo(c2x, c2y, s2x, s2y);
      ctx.closePath();
      ctx.shadowBlur = 0;
      ctx.fillStyle = BODY_FILL;
      ctx.fill();
      ctx.shadowBlur = glowPx();
      ctx.stroke();
    }
  }

  function draw(time) {
    const colorStr = rgba(COLOR_RGB, 1);
    const lw = Math.max(0.8, scale);

    // ---- Background + the warm pool of light around the scorpion ----
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.globalAlpha = 1;
    ctx.shadowBlur = 0;
    ctx.globalCompositeOperation = 'source-over';
    ctx.drawImage(bgCanvas, 0, 0, width, height);

    const pr = 290 * scale;
    const lx = spine[1].x;
    const ly = spine[1].y;
    const pool = ctx.createRadialGradient(lx, ly, 0, lx, ly, pr);
    pool.addColorStop(0, rgba(COLOR_RGB, 0.13 + strike.env * 0.07));
    pool.addColorStop(1, rgba(COLOR_RGB, 0));
    ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = pool;
    ctx.fillRect(lx - pr, ly - pr, pr * 2, pr * 2);
    ctx.globalCompositeOperation = 'source-over';

    ctx.save();
    if (shake > 0.15) {
      ctx.translate((Math.random() - 0.5) * shake * 2, (Math.random() - 0.5) * shake * 2);
    }

    // ---- Footprints, dust, shockwaves ----
    drawFx('under');

    // ---- Pointer marker (so you can see what the claws are reaching for) ----
    if (pointer.active) {
      ctx.shadowBlur = 0;
      ctx.strokeStyle = rgba(COLOR_RGB, 0.32);
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(pointer.x, pointer.y, 5 + Math.sin(time * 0.006) * 1.2, 0, TAU);
      ctx.stroke();
      ctx.fillStyle = rgba(COLOR_RGB, 0.7);
      dot(pointer.x, pointer.y, 1.5);
    }

    // Neon wireframe style
    ctx.strokeStyle = colorStr;
    ctx.shadowColor = colorStr;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    // ---- Legs ----
    const centre = { x: lerp(head.x, spine[0].x, 0.5), y: lerp(head.y, spine[0].y, 0.5) };
    ctx.lineWidth = 1.7 * lw;
    for (const leg of legs) {
      const hip = hipOf(leg);
      const l1 = BONE1 * LEG_SCALE[leg.index] * scale;
      const l2 = BONE2 * LEG_SCALE[leg.index] * scale;
      const knee = solveKnee(hip, leg.foot, l1, l2, centre);

      // Little hooked tip continuing the lower bone's direction
      let tx = leg.foot.x - knee.x;
      let ty = leg.foot.y - knee.y;
      const tl = Math.hypot(tx, ty) || 1;
      tx = leg.foot.x + (tx / tl) * 5 * scale;
      ty = leg.foot.y + (ty / tl) * 5 * scale;

      ctx.shadowBlur = glowPx();
      ctx.beginPath();
      ctx.moveTo(hip.x, hip.y);
      ctx.lineTo(knee.x, knee.y);
      ctx.lineTo(leg.foot.x, leg.foot.y);
      ctx.lineTo(tx, ty);
      ctx.stroke();

      ctx.fillStyle = colorStr;
      dot(knee.x, knee.y, 2 * scale);
    }

    // ---- Pedipalp arms (drawn before the carapace so the shoulders tuck under it) ----
    ctx.lineWidth = 2.5 * lw;
    for (const c of claws) {
      ctx.shadowBlur = glowPx();
      ctx.beginPath();
      ctx.moveTo(c.shoulder.x, c.shoulder.y);
      ctx.lineTo(c.elbow.x, c.elbow.y);
      ctx.lineTo(c.wrist.x, c.wrist.y);
      ctx.stroke();
      ctx.fillStyle = colorStr;
      dot(c.elbow.x, c.elbow.y, 2.6 * scale);
    }
    ctx.lineWidth = 1.7 * lw;
    for (const c of claws) drawClaw(c);

    // ---- Abdomen plates, back to front ----
    ctx.lineWidth = 1.6 * lw;
    for (let i = spine.length - 1; i >= 0; i--) {
      const n = spine[i];
      const pr_ = i === 0 ? head : spine[i - 1];
      const rot = Math.atan2(n.y - pr_.y, n.x - pr_.x);
      plate(n.x, n.y, SPINE[i] * 0.68 * scale, SEG_R[i] * scale, rot);
    }

    // Keel line down the middle of the back
    ctx.shadowBlur = 0;
    ctx.strokeStyle = rgba(COLOR_RGB, 0.4);
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(head.x, head.y);
    for (const n of spine) ctx.lineTo(n.x, n.y);
    ctx.stroke();
    ctx.strokeStyle = colorStr;

    // ---- Carapace + eyes ----
    ctx.lineWidth = 1.8 * lw;
    const hx = Math.cos(head.heading);
    const hy = Math.sin(head.heading);
    plate(head.x, head.y, CARAPACE_RX * scale, CARAPACE_RY * scale, head.heading);
    ctx.lineWidth = 1.2 * lw;
    ctx.globalAlpha = 0.6;
    plate(head.x + hx * 3 * scale, head.y + hy * 3 * scale, 8 * scale, 7 * scale, head.heading);
    ctx.globalAlpha = 1;

    ctx.fillStyle = colorStr;
    ctx.shadowBlur = glowPx();
    for (const s of [-1, 1]) {
      // two median eyes
      dot(head.x + hx * 5 * scale - hy * s * 2.6 * scale, head.y + hy * 5 * scale + hx * s * 2.6 * scale, 1.6 * scale);
      // side eyes
      for (const ang of [0.85, 1.1]) {
        const ea = head.heading + s * ang;
        dot(head.x + Math.cos(ea) * CARAPACE_RX * 0.78 * scale, head.y + Math.sin(ea) * CARAPACE_RY * 0.9 * scale, 1 * scale);
      }
    }

    // ---- Tail ----
    const anchor = spine[spine.length - 1];

    // thin cord linking the beads
    ctx.strokeStyle = rgba(COLOR_RGB, 0.55);
    ctx.lineWidth = 1.2 * lw;
    ctx.shadowBlur = 0;
    ctx.beginPath();
    ctx.moveTo(anchor.x, anchor.y);
    for (const n of tail) ctx.lineTo(n.x, n.y);
    ctx.stroke();

    ctx.strokeStyle = colorStr;
    ctx.lineWidth = 1.6 * lw;
    for (let i = 0; i < TAIL_N; i++) {
      const from = i === 0 ? anchor : tail[i - 1];
      const to = tail[i];
      const rot = Math.atan2(to.y - from.y, to.x - from.x);
      plate((from.x + to.x) / 2, (from.y + to.y) / 2, TAIL_SEG * 0.6 * scale, TAIL_R[i] * scale, rot);
    }

    // ---- Stinger: glows hotter during a sting ----
    const tip = tail[TAIL_N - 1];
    const prevN = tail[TAIL_N - 2];
    let dx = tip.x - prevN.x;
    let dy = tip.y - prevN.y;
    const dl = Math.hypot(dx, dy) || 1;
    dx /= dl; dy /= dl;
    const px = -dy;
    const py = dx;
    const s = scale;

    const stingCol = mixRGB(STING_RGB, FLASH_RGB, strike.env * strike.env);
    const stingStr = rgba(stingCol, 1);
    ctx.fillStyle = stingStr;
    ctx.strokeStyle = stingStr;
    ctx.shadowColor = stingStr;
    ctx.shadowBlur = (GLOW_BLUR + 22 * strike.env) * dpr;
    ctx.lineWidth = 1.2 * lw;

    ctx.beginPath();
    ctx.moveTo(tip.x + px * 3.3 * s + dx * 2 * s, tip.y + py * 3.3 * s + dy * 2 * s);
    ctx.quadraticCurveTo(
      tip.x + dx * 11 * s + px * 4.5 * s, tip.y + dy * 11 * s + py * 4.5 * s,
      tip.x + dx * STING_LEN * s + px * 5 * s, tip.y + dy * STING_LEN * s + py * 5 * s
    );
    ctx.quadraticCurveTo(
      tip.x + dx * 8 * s - px * 0.5 * s, tip.y + dy * 8 * s - py * 0.5 * s,
      tip.x - px * 3.3 * s + dx * 2 * s, tip.y - py * 3.3 * s + dy * 2 * s
    );
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // ---- Sparks fly over everything ----
    drawFx('over');

    ctx.restore();
  }

  /* ------------------------------------------------------------------
     Main loop
  ------------------------------------------------------------------- */
  let last = performance.now();

  function frame(now) {
    const dt = Math.min(0.05, Math.max(0.001, (now - last) / 1000));
    last = now;

    updateBody(dt, now);
    updateClaws(dt, now);
    updateLegs(dt);
    updateTail(dt, now);
    updateFx(dt);
    draw(now);

    requestAnimationFrame(frame);
  }

  resize();
  init();
  requestAnimationFrame(frame);
})();
