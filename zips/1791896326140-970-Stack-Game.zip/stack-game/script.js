(() => {
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d', { alpha: true });
  const $score = document.getElementById('score');
  const $best = document.getElementById('best');
  const $toast = document.getElementById('toast');
  const $overlay = document.getElementById('overlay');
  const $msg = document.getElementById('msg');
  const $final = document.getElementById('final');
  const $play = document.getElementById('play');

  let W, H, DPR, BH, BASE_W, FW, FX;   // FW/FX = play-field width / left edge
  const PERFECT_TOL = 6;        // px tolerance for a "perfect" drop
  let best = 0;
  try { best = +localStorage.getItem('lhStackBest') || 0; } catch (e) {}
  $best.textContent = 'BEST ' + best;

  let state = 'ready';          // ready | playing | over
  let stack, cur, falling, rings, camY, camTarget, combo, score, overAt;

  function resize() {
    DPR = Math.min(window.devicePixelRatio || 1, 1.5);
    W = window.innerWidth; H = window.innerHeight;
    canvas.width = W * DPR; canvas.height = H * DPR;
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    BH = Math.max(26, Math.min(40, H * 0.05));
    FW = Math.min(W, 520);                 // play field stays phone-sized on wide screens
    FX = (W - FW) / 2;
    BASE_W = Math.min(FW * 0.6, 280);
  }
  window.addEventListener('resize', resize);
  resize();

  const colorCache = {};
  const color = i => colorCache[i] || (colorCache[i] = (() => {
    const h = (195 + i * 9) % 360;
    return { h, base: `hsl(${h} 70% 55%)`, top: `hsl(${h} 75% 72%)`, side: `hsl(${h} 70% 38%)` };
  })());

  function reset() {
    score = 0; combo = 0; camY = 0; camTarget = 0;
    falling = []; rings = [];
    stack = [{ x: (W - BASE_W) / 2, w: BASE_W, i: 0 }];
    $score.textContent = '0';
    spawn();
  }

  function spawn() {
    const top = stack[stack.length - 1];
    const i = stack.length;
    const fromLeft = i % 2 === 0;
    // speed scales with the play-field width (px per 60fps frame), so it feels the same on any screen
    const speed = FW * Math.min(0.0065 + i * 0.00022, 0.017);
    cur = { w: top.w, x: fromLeft ? FX - top.w : FX + FW, dir: fromLeft ? 1 : -1, speed, i };
  }

  function toast(text) {
    $toast.textContent = text;
    $toast.classList.add('show');
    clearTimeout(toast.t);
    toast.t = setTimeout(() => $toast.classList.remove('show'), 650);
  }

  // ---------- sound (tiny WebAudio blips, no files needed) ----------
  let actx;
  function blip(freq, dur = 0.12, type = 'triangle', vol = 0.08) {
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      const o = actx.createOscillator(), g = actx.createGain();
      o.type = type; o.frequency.value = freq;
      g.gain.setValueAtTime(vol, actx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.0001, actx.currentTime + dur);
      o.connect(g); g.connect(actx.destination);
      o.start(); o.stop(actx.currentTime + dur);
    } catch (e) {}
  }

  // ---------- game flow ----------
  function start() {
    reset();
    state = 'playing';
    $overlay.classList.add('hidden');
  }

  function drop() {
    const top = stack[stack.length - 1];
    const left = Math.max(cur.x, top.x);
    const right = Math.min(cur.x + cur.w, top.x + top.w);
    const overlap = right - left;

    if (overlap <= 0) return gameOver();

    const offset = cur.x - top.x;
    let placed;

    if (Math.abs(offset) <= PERFECT_TOL) {
      combo++;
      placed = { x: top.x, w: top.w, i: cur.i };
      rings.push({ x: placed.x, w: placed.w, i: cur.i, t: 0 });
      if (combo >= 3 && placed.w < BASE_W) {          // reward streaks: grow back
        const grow = Math.min(10, BASE_W - placed.w);
        placed.x -= grow / 2; placed.w += grow;
      }
      toast(combo > 1 ? `PERFECT ×${combo}` : 'PERFECT');
      blip(520 + Math.min(combo, 10) * 60, 0.18, 'sine', 0.1);
    } else {
      combo = 0;
      placed = { x: left, w: overlap, i: cur.i };
      // overhanging piece falls away
      if (offset < 0) falling.push({ x: cur.x, w: -offset, i: cur.i, vy: 0, vx: -1.2, rot: 0, vr: -0.03 });
      else falling.push({ x: right, w: offset, i: cur.i, vy: 0, vx: 1.2, rot: 0, vr: 0.03 });
      blip(240, 0.09, 'square', 0.05);
    }

    stack.push(placed);
    score++;
    $score.textContent = score;
    camTarget = Math.max(0, (stack.length - 5) * BH);
    spawn();
  }

  function gameOver() {
    state = 'over';
    overAt = performance.now();
    falling.push({ x: cur.x, w: cur.w, i: cur.i, vy: 0, vx: 0, rot: 0, vr: 0.02 });
    cur = null;
    blip(120, 0.5, 'sawtooth', 0.08);
    const newBest = score > best;
    if (newBest) { best = score; try { localStorage.setItem('lhStackBest', best); } catch (e) {} }
    $best.textContent = 'BEST ' + best;
    setTimeout(() => {
      $msg.innerHTML = newBest && score > 0 ? '🔥 New best score!' : 'The tower has fallen.';
      $final.textContent = `SCORE ${score}  ·  BEST ${best}`;
      $play.textContent = 'RETRY';
      $overlay.classList.remove('hidden');
    }, 700);
  }

  // ---------- input ----------
  function act() {
    if (state === 'playing') drop();
  }
  window.addEventListener('pointerdown', e => {
    if (e.target === $play) return;
    if (state === 'playing') act();
    else if (state === 'ready' && performance.now() > 0) start();
    else if (state === 'over' && performance.now() - overAt > 900) start();
  });
  window.addEventListener('keydown', e => {
    if (e.code === 'Space' || e.code === 'Enter') {
      e.preventDefault();
      if (state === 'playing') act();
      else if (state === 'ready' || (state === 'over' && performance.now() - overAt > 900)) start();
    }
  });
  $play.addEventListener('click', start);

  // ---------- drawing ----------
  const groundY = () => H * 0.82;
  const sy = i => groundY() - (i + 1) * BH + camY;   // screen y of block index i

  function drawBlock(x, y, w, i, alpha = 1, rot = 0) {
    const c = color(i);
    ctx.save();
    ctx.globalAlpha = alpha;
    if (rot) { ctx.translate(x + w / 2, y + BH / 2); ctx.rotate(rot); ctx.translate(-(x + w / 2), -(y + BH / 2)); }
    ctx.fillStyle = c.base;
    ctx.fillRect(x, y, w, BH - 2);
    ctx.fillStyle = c.top;  ctx.fillRect(x, y, w, 5);               // lit top edge
    ctx.fillStyle = c.side; ctx.fillRect(x, y + BH - 8, w, 6);      // shaded bottom
    ctx.fillStyle = 'rgba(255,255,255,.12)'; ctx.fillRect(x, y + 5, 3, BH - 13);
    ctx.restore();
  }

  function update(dt) {
    camY += (camTarget - camY) * Math.min(1, 0.09 * dt);

    if (state === 'playing' && cur) {
      cur.x += cur.dir * cur.speed * dt;
      const min = FX - cur.w * 0.45, max = FX + FW - cur.w * 0.55;
      if (cur.x > max) { cur.x = max; cur.dir = -1; }
      if (cur.x < min) { cur.x = min; cur.dir = 1; }
    }
    falling.forEach(f => { f.vy += 0.55 * dt; f.x += f.vx * dt; f.rot += f.vr * dt; f.y = (f.y ?? sy(f.i) - camY) + f.vy * dt; });
    falling = falling.filter(f => f.y + camY < H + 200);
    rings.forEach(r => r.t += 0.045 * dt);
    rings = rings.filter(r => r.t < 1);
  }

  function render() {
    ctx.clearRect(0, 0, W, H);

    // ground glow
    const g = ctx.createLinearGradient(0, groundY(), 0, H);
    g.addColorStop(0, 'rgba(255,106,26,.18)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, groundY() + camY, W, H);
    if (W > FW + 40) {                               // faint column framing the play area on desktop
      ctx.fillStyle = 'rgba(5,9,12,.22)';
      ctx.fillRect(FX, 0, FW, H);
      ctx.fillStyle = 'rgba(255,106,26,.25)';
      ctx.fillRect(FX, 0, 1, H); ctx.fillRect(FX + FW - 1, 0, 1, H);
    }

    stack.forEach(b => drawBlock(b.x, sy(b.i), b.w, b.i));
    if (cur) drawBlock(cur.x, sy(cur.i), cur.w, cur.i);
    falling.forEach(f => drawBlock(f.x, f.y + camY, f.w, f.i, 0.9, f.rot));

    rings.forEach(r => {
      ctx.save();
      ctx.globalAlpha = 1 - r.t;
      ctx.strokeStyle = '#ffb36b'; ctx.lineWidth = 2;
      const grow = r.t * 22;
      ctx.strokeRect(r.x - grow / 2, sy(r.i) - grow / 2, r.w + grow, BH + grow);
      ctx.restore();
    });
  }

  let last = performance.now();
  function loop(now) {
    const dt = Math.min((now - last) / 16.667, 3); last = now;
    update(dt); render();
    requestAnimationFrame(loop);
  }

  reset();
  requestAnimationFrame(loop);
})();
