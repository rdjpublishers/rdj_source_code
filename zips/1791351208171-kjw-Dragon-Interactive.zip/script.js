(() => {
  'use strict';

  /* ------------------------------------------------------------------ *
   *  Helpers
   * ------------------------------------------------------------------ */
  const TAU = Math.PI * 2;
  const lerp = (a, b, t) => a + (b - a) * t;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const smooth = (t) => { t = clamp(t, 0, 1); return t * t * (3 - 2 * t); };
  const wrap = (a) => { while (a > Math.PI) a -= TAU; while (a < -Math.PI) a += TAU; return a; };
  const hsla = (h, s, l, a = 1) => `hsla(${Math.round(h)},${s}%,${l}%,${a})`;
  const rand = (a, b) => a + Math.random() * (b - a);

  /* ------------------------------------------------------------------ *
   *  Elements, themes, options
   * ------------------------------------------------------------------ */
  const canvas = document.getElementById('scene');
  const ctx = canvas.getContext('2d');
  const reticle = document.getElementById('reticle');
  const hint = document.getElementById('hint');
  const swatchBox = document.getElementById('swatches');

  const THEMES = [
    { id: 'Emerald', h: 150, eye: 'hsl(48 100% 62%)' },
    { id: 'Crimson', h: 356, eye: 'hsl(52 100% 66%)' },
    { id: 'Azure',   h: 202, eye: 'hsl(176 100% 72%)' },
    { id: 'Gold',    h: 42,  eye: 'hsl(6 100% 56%)' },
    { id: 'Violet',  h: 275, eye: 'hsl(318 100% 72%)' },
  ];
  let theme = THEMES[0];
  const opts = { wings: true, embers: true };
  const BONE = 'hsl(42 32% 82%)';

  /* ------------------------------------------------------------------ *
   *  Canvas / background
   * ------------------------------------------------------------------ */
  let W = 0, H = 0, DPR = 1;
  let S = 1, SEG = 11;
  const bg = document.createElement('canvas');
  const bctx = bg.getContext('2d');
  let stars = [];

  function initStars() {
    const n = clamp(Math.floor((W * H) / 5500), 90, 320);
    stars = Array.from({ length: n }, () => ({
      x: Math.random() * W,
      y: Math.random() * H * 0.86,
      r: Math.random() * 1.3 + 0.4,
      p: Math.random() * TAU,
      s: 0.6 + Math.random() * 1.8,
      d: Math.random(),
    }));
  }

  function ridge(c, base, amp, seed, fill) {
    c.beginPath();
    c.moveTo(0, H);
    for (let x = 0; x <= W + 6; x += 6) {
      const y = base - amp * (0.5 * Math.sin(x * 0.004 + seed) + 0.3 * Math.sin(x * 0.011 + seed * 2.3) + 0.2 * Math.sin(x * 0.027 + seed * 4.1));
      c.lineTo(x, y);
    }
    c.lineTo(W, H);
    c.closePath();
    c.fillStyle = fill;
    c.fill();
  }

  function renderBg() {
    const c = bctx;
    const h = theme.h;
    c.setTransform(DPR, 0, 0, DPR, 0, 0);
    c.clearRect(0, 0, W, H);

    const sky = c.createLinearGradient(0, 0, 0, H);
    sky.addColorStop(0, 'hsl(235 48% 4%)');
    sky.addColorStop(0.55, `hsl(${h} 32% 7%)`);
    sky.addColorStop(1, `hsl(${h} 42% 11%)`);
    c.fillStyle = sky;
    c.fillRect(0, 0, W, H);

    const blobs = [[0.2, 0.3, 0.5, 0], [0.78, 0.55, 0.55, 40], [0.5, 0.12, 0.4, -30]];
    for (const [fx, fy, fr, dh] of blobs) {
      const R = Math.max(W, H) * fr;
      const g = c.createRadialGradient(W * fx, H * fy, 0, W * fx, H * fy, R);
      g.addColorStop(0, hsla(h + dh, 70, 34, 0.16));
      g.addColorStop(1, hsla(h + dh, 70, 34, 0));
      c.fillStyle = g;
      c.fillRect(0, 0, W, H);
    }

    // moon
    const mx = W * 0.82, my = H * 0.19, mr = Math.min(W, H) * 0.055;
    let g = c.createRadialGradient(mx, my, mr * 0.8, mx, my, mr * 5);
    g.addColorStop(0, 'rgba(220,230,255,0.22)');
    g.addColorStop(1, 'rgba(220,230,255,0)');
    c.fillStyle = g;
    c.fillRect(mx - mr * 5, my - mr * 5, mr * 10, mr * 10);
    g = c.createRadialGradient(mx - mr * 0.3, my - mr * 0.3, mr * 0.1, mx, my, mr);
    g.addColorStop(0, '#f4f6ff');
    g.addColorStop(1, '#b9c4e0');
    c.fillStyle = g;
    c.beginPath(); c.arc(mx, my, mr, 0, TAU); c.fill();
    c.fillStyle = 'rgba(80,95,140,0.14)';
    [[-0.35, -0.2, 0.22], [0.25, 0.1, 0.3], [-0.1, 0.45, 0.16], [0.35, -0.4, 0.13]].forEach(([dx, dy, rr]) => {
      c.beginPath(); c.arc(mx + dx * mr, my + dy * mr, rr * mr, 0, TAU); c.fill();
    });

    // horizon glow + mountains
    g = c.createRadialGradient(W / 2, H, 0, W / 2, H, H * 0.85);
    g.addColorStop(0, hsla(h, 75, 38, 0.3));
    g.addColorStop(1, hsla(h, 75, 38, 0));
    c.fillStyle = g;
    c.fillRect(0, 0, W, H);
    ridge(c, H * 0.8, 72, 1.3, `hsl(${h} 30% 9%)`);
    ridge(c, H * 0.88, 60, 4.2, `hsl(${h} 28% 5%)`);
    ridge(c, H * 0.97, 40, 7.7, `hsl(${h} 25% 2.5%)`);
  }

  /* ------------------------------------------------------------------ *
   *  Dragon model
   * ------------------------------------------------------------------ */
  const N = 58;          // body segments
  const WI = 10;         // wing shoulder segment
  const segs = [];
  const rad = new Float32Array(N);
  const Lx = new Float32Array(N), Ly = new Float32Array(N);
  const Rx = new Float32Array(N), Ry = new Float32Array(N);
  const head = { x: 0, y: 0, vx: 0, vy: 0, a: 0, spd: 0 };
  const legs = [
    { seg: 12, side: -1, front: true },
    { seg: 12, side: 1, front: true },
    { seg: 30, side: -1, front: false },
    { seg: 30, side: 1, front: false },
  ];

  const rAt = (i) => {
    const t = i / (N - 1);
    return S * (2 + 13 * Math.pow(1 - t, 1.3) * (0.62 + 0.38 * smooth(t / 0.22)) + 4 * Math.exp(-Math.pow((t - 0.2) / 0.09, 2)));
  };
  const computeRad = () => { for (let i = 0; i < N; i++) rad[i] = rAt(i); };

  function initDragon() {
    segs.length = 0;
    for (let i = 0; i < N; i++) segs.push({ x: -90 * S - i * SEG, y: H * 0.5, a: 0 });
    head.x = segs[0].x; head.y = segs[0].y; head.a = 0; head.spd = 0;
    for (const l of legs) {
      const s = segs[l.seg];
      l.fx = l.tx = s.x; l.fy = l.ty = s.y;
    }
  }

  function resize() {
    DPR = Math.min(window.devicePixelRatio || 1, 2);
    W = window.innerWidth;
    H = window.innerHeight;
    canvas.width = Math.round(W * DPR);
    canvas.height = Math.round(H * DPR);
    bg.width = canvas.width;
    bg.height = canvas.height;
    S = clamp(Math.min(W, H) / 820, 0.55, 1.15);
    SEG = 11 * S;
    computeRad();
    initStars();
    renderBg();
    if (!segs.length) initDragon();
  }

  /* ------------------------------------------------------------------ *
   *  Input
   * ------------------------------------------------------------------ */
  let time = 0;
  let lastMove = -100;
  const pointer = { x: 0, y: 0 };
  let pointerFiring = false;
  let keyFiring = false;
  let touchTimer = 0;
  let touchStart = null;
  let interacted = false;

  function markInteracted() {
    if (interacted) return;
    interacted = true;
    setTimeout(() => hint.classList.add('fade'), 9000);
  }

  window.addEventListener('pointermove', (e) => {
    pointer.x = e.clientX; pointer.y = e.clientY;
    lastMove = time;
    if (e.pointerType !== 'touch') {
      reticle.classList.add('on');
      reticle.style.transform = `translate3d(${e.clientX}px,${e.clientY}px,0)`;
    } else if (touchStart && Math.hypot(e.clientX - touchStart.x, e.clientY - touchStart.y) > 14) {
      clearTimeout(touchTimer);
    }
    markInteracted();
  }, { passive: true });

  window.addEventListener('pointerdown', (e) => {
    if (e.target.closest('.ui')) return;
    pointer.x = e.clientX; pointer.y = e.clientY;
    lastMove = time;
    if (e.pointerType === 'touch') {
      touchStart = { x: e.clientX, y: e.clientY };
      clearTimeout(touchTimer);
      touchTimer = setTimeout(() => { pointerFiring = true; }, 220);
    } else if (e.button === 0) {
      pointerFiring = true;
      reticle.classList.add('down');
    }
    markInteracted();
  });

  const release = () => {
    clearTimeout(touchTimer);
    touchStart = null;
    pointerFiring = false;
    reticle.classList.remove('down');
  };
  window.addEventListener('pointerup', release);
  window.addEventListener('pointercancel', release);
  window.addEventListener('blur', () => { release(); keyFiring = false; });
  document.addEventListener('pointerleave', () => reticle.classList.remove('on'));

  window.addEventListener('keydown', (e) => {
    if (e.code === 'Space' && !e.target.closest('button')) {
      e.preventDefault();
      keyFiring = true;
      reticle.classList.add('down');
      markInteracted();
    } else if (e.key >= '1' && e.key <= String(THEMES.length)) {
      setTheme(Number(e.key) - 1);
    }
  });
  window.addEventListener('keyup', (e) => {
    if (e.code === 'Space') { keyFiring = false; if (!pointerFiring) reticle.classList.remove('down'); }
  });

  /* ------------------------------------------------------------------ *
   *  UI wiring
   * ------------------------------------------------------------------ */
  function setTheme(i) {
    theme = THEMES[i];
    document.documentElement.style.setProperty('--hue', theme.h);
    swatchBox.querySelectorAll('.swatch').forEach((b, k) => b.setAttribute('aria-pressed', String(k === i)));
    renderBg();
  }

  THEMES.forEach((t, i) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'swatch';
    b.style.setProperty('--sw', t.h);
    b.setAttribute('aria-label', `${t.id} dragon`);
    b.title = `${t.id} (${i + 1})`;
    b.setAttribute('aria-pressed', String(i === 0));
    b.addEventListener('click', () => setTheme(i));
    swatchBox.appendChild(b);
  });

  document.querySelectorAll('.toggle').forEach((b) => {
    b.addEventListener('click', () => {
      const k = b.dataset.toggle;
      opts[k] = !opts[k];
      b.setAttribute('aria-pressed', String(opts[k]));
    });
  });

  /* ------------------------------------------------------------------ *
   *  Particles (fire, sparks, embers)
   * ------------------------------------------------------------------ */
  const fire = [];
  const sparks = [];
  let fireAcc = 0, sparkAcc = 0, emberAcc = 0;
  let jaw = 0;
  let flapPhase = 0, flap = 0;

  const fireColor = (u) => {
    if (u < 0.25) { const k = u / 0.25; return [lerp(58, 40, k), lerp(88, 62, k)]; }
    if (u < 0.65) { const k = (u - 0.25) / 0.4; return [lerp(40, 14, k), lerp(62, 48, k)]; }
    const k = (u - 0.65) / 0.35; return [lerp(14, 5, k), lerp(48, 26, k)];
  };
  const SPRITES = Array.from({ length: 8 }, (_, i) => {
    const [h, l] = fireColor(i / 7);
    const c = document.createElement('canvas');
    c.width = c.height = 64;
    const x = c.getContext('2d');
    const g = x.createRadialGradient(32, 32, 0, 32, 32, 32);
    g.addColorStop(0, hsla(h, 100, l, 1));
    g.addColorStop(0.4, hsla(h, 100, l, 0.45));
    g.addColorStop(1, hsla(h, 100, l, 0));
    x.fillStyle = g;
    x.fillRect(0, 0, 64, 64);
    return c;
  });

  const mouth = () => ({
    x: head.x + Math.cos(head.a) * 46 * S,
    y: head.y + Math.sin(head.a) * 46 * S,
  });

  function spawnFire() {
    const m = mouth();
    const a = head.a + (Math.random() - 0.5) * 0.17;
    const sp = rand(520, 940) * S;
    fire.push({
      x: m.x, y: m.y,
      vx: Math.cos(a) * sp + head.vx * 0.4,
      vy: Math.sin(a) * sp + head.vy * 0.4,
      age: 0, life: rand(0.5, 0.95), size: rand(5, 11) * S,
    });
  }

  function spawnSpark() {
    const m = mouth();
    const a = head.a + (Math.random() - 0.5) * 0.6;
    const sp = rand(300, 900) * S;
    sparks.push({
      x: m.x, y: m.y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp,
      age: 0, life: rand(0.7, 1.6), size: rand(0.8, 2.2) * Math.max(S, 0.8),
      hue: rand(36, 56), drag: 1.8,
    });
  }

  function spawnEmber() {
    const i = Math.floor(rand(6, N - 2));
    const s = segs[i];
    sparks.push({
      x: s.x + rand(-1, 1) * rad[i], y: s.y + rand(-1, 1) * rad[i],
      vx: rand(-40, 40), vy: rand(-60, 10),
      age: 0, life: rand(0.8, 1.7), size: rand(0.9, 2.2) * Math.max(S, 0.8),
      hue: theme.h + rand(-10, 25), drag: 0.8, tint: true,
    });
  }

  /* ------------------------------------------------------------------ *
   *  Update
   * ------------------------------------------------------------------ */
  function update(dt, t) {
    const sinceMove = t - lastMove;
    const idle = sinceMove > 5;
    let tx = pointer.x, ty = pointer.y;

    if (idle) {
      tx = W * 0.5 + Math.cos(t * 0.45) * W * 0.34;
      ty = H * 0.46 + Math.sin(t * 0.9) * H * 0.22;
    } else if (sinceMove > 0.6) {
      tx += Math.cos(t * 1.7) * 26 * S;
      ty += Math.sin(t * 2.3) * 20 * S;
    }

    const autoFire = idle && (t % 9) > 6.2 && (t % 9) < 7.6;
    const firing = pointerFiring || keyFiring || autoFire;

    // head: eased, speed-limited chase
    const dx = tx - head.x, dy = ty - head.y;
    const dist = Math.hypot(dx, dy) || 0.0001;
    const maxSp = (idle ? 420 : 1000) * S;
    const sp = Math.min(dist * 5.5, maxSp);
    head.vx = (dx / dist) * sp;
    head.vy = (dy / dist) * sp;
    head.x += head.vx * dt;
    head.y += head.vy * dt;
    head.spd = lerp(head.spd, sp, Math.min(1, dt * 8));
    if (sp > 35 * S) head.a += wrap(Math.atan2(head.vy, head.vx) - head.a) * Math.min(1, dt * 9);

    // body: follow the leader with bend limit + travelling wave
    segs[0].x = head.x; segs[0].y = head.y; segs[0].a = head.a;
    const amp = 0.35 + clamp(head.spd / (500 * S), 0, 1) * 0.9;
    for (let i = 1; i < N; i++) {
      const p = segs[i - 1], s = segs[i];
      let ang = Math.atan2(p.y - s.y, p.x - s.x);
      ang = p.a + clamp(wrap(ang - p.a), -0.32, 0.32);
      ang += Math.sin(t * 5 - i * 0.38) * 0.05 * amp * smooth(i / 9) * (1 - (i / N) * 0.3);
      s.a = ang;
      s.x = p.x - Math.cos(ang) * SEG;
      s.y = p.y - Math.sin(ang) * SEG;
    }

    // wings
    flapPhase += dt * (2.6 + clamp(head.spd / (300 * S), 0, 1) * 4 + (firing ? 1.5 : 0));
    flap = Math.sin(flapPhase) * 0.9 + Math.sin(flapPhase * 2) * 0.12;

    // legs
    const k = 1 - Math.exp(-dt * 22);
    for (const l of legs) {
      const s = segs[l.seg], r = rad[l.seg];
      const nx = Math.cos(s.a + l.side * Math.PI / 2), ny = Math.sin(s.a + l.side * Math.PI / 2);
      const fx = Math.cos(s.a), fy = Math.sin(s.a);
      const reach = (l.front ? 40 : 36) * S;
      const lead = clamp(head.spd * 0.05, 0, 22 * S) * (l.front ? 1 : 0.7);
      const px = s.x + nx * (r + reach * 0.55) + fx * lead;
      const py = s.y + ny * (r + reach * 0.55) + fy * lead;
      if (Math.hypot(l.fx - px, l.fy - py) > 46 * S) {
        l.tx = px + fx * 16 * S; l.ty = py + fy * 16 * S;
      }
      l.fx += (l.tx - l.fx) * k;
      l.fy += (l.ty - l.fy) * k;
    }

    // fire
    jaw += ((firing ? 1 : 0) - jaw) * Math.min(1, dt * 14);
    if (firing && jaw > 0.35) {
      fireAcc += dt * 480;
      while (fireAcc >= 1) { fireAcc--; if (fire.length < 900) spawnFire(); }
      sparkAcc += dt * 70;
      while (sparkAcc >= 1) { sparkAcc--; if (sparks.length < 260) spawnSpark(); }
    } else { fireAcc = 0; sparkAcc = 0; }

    if (opts.embers && head.spd > 60 * S) {
      emberAcc += dt * 34;
      while (emberAcc >= 1) { emberAcc--; if (sparks.length < 260) spawnEmber(); }
    }

    for (let i = fire.length - 1; i >= 0; i--) {
      const p = fire[i];
      p.age += dt;
      if (p.age >= p.life) { fire[i] = fire[fire.length - 1]; fire.pop(); continue; }
      const drag = Math.exp(-1.6 * dt);
      p.vx = p.vx * drag + (Math.random() - 0.5) * 420 * dt;
      p.vy = p.vy * drag + (Math.random() - 0.5) * 420 * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
    }
    for (let i = sparks.length - 1; i >= 0; i--) {
      const p = sparks[i];
      p.age += dt;
      if (p.age >= p.life) { sparks[i] = sparks[sparks.length - 1]; sparks.pop(); continue; }
      const drag = Math.exp(-p.drag * dt);
      p.vx *= drag; p.vy *= drag;
      if (p.tint) p.vy -= 30 * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
    }
  }

  /* ------------------------------------------------------------------ *
   *  Drawing
   * ------------------------------------------------------------------ */
  function drawStars(t) {
    const ox = (pointer.x - W / 2), oy = (pointer.y - H / 2);
    ctx.fillStyle = '#fff';
    for (const s of stars) {
      ctx.globalAlpha = 0.3 + 0.7 * (0.5 + 0.5 * Math.sin(t * s.s + s.p));
      ctx.fillRect(s.x - ox * s.d * 0.012, s.y - oy * s.d * 0.012, s.r * 1.5, s.r * 1.5);
    }
    ctx.globalAlpha = 1;
  }

  function drawFireGlow() {
    if (jaw < 0.03) return;
    const m = mouth();
    const R = (300 + Math.random() * 25) * S;
    const g = ctx.createRadialGradient(m.x, m.y, 0, m.x, m.y, R);
    g.addColorStop(0, `hsla(34,100%,58%,${0.32 * jaw})`);
    g.addColorStop(0.5, `hsla(18,100%,45%,${0.12 * jaw})`);
    g.addColorStop(1, 'hsla(10,100%,40%,0)');
    ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = g;
    ctx.fillRect(m.x - R, m.y - R, R * 2, R * 2);
    ctx.globalCompositeOperation = 'source-over';
  }

  function computeEdges() {
    for (let i = 0; i < N; i++) {
      const s = segs[i], r = rad[i];
      const nx = -Math.sin(s.a), ny = Math.cos(s.a);
      Lx[i] = s.x + nx * r; Ly[i] = s.y + ny * r;
      Rx[i] = s.x - nx * r; Ry[i] = s.y - ny * r;
    }
  }

  function bodyPath() {
    ctx.beginPath();
    ctx.moveTo(Lx[0], Ly[0]);
    for (let i = 1; i < N; i++) ctx.lineTo(Lx[i], Ly[i]);
    for (let i = N - 1; i >= 0; i--) ctx.lineTo(Rx[i], Ry[i]);
    ctx.closePath();
  }

  function drawLeg(l) {
    const h = theme.h;
    const s = segs[l.seg], r = rad[l.seg];
    const nx = Math.cos(s.a + l.side * Math.PI / 2), ny = Math.sin(s.a + l.side * Math.PI / 2);
    const hx = s.x + nx * r * 0.6, hy = s.y + ny * r * 0.6;
    const ddx = l.fx - hx, ddy = l.fy - hy;
    const d = Math.hypot(ddx, ddy) || 0.01;
    const l1 = 30 * S, l2 = 34 * S;
    const dd = clamp(d, Math.abs(l1 - l2) + 1, l1 + l2 - 1);
    const base = Math.atan2(ddy, ddx);
    const A = Math.acos(clamp((l1 * l1 + dd * dd - l2 * l2) / (2 * l1 * dd), -1, 1));
    const k1x = hx + Math.cos(base + A) * l1, k1y = hy + Math.sin(base + A) * l1;
    const k2x = hx + Math.cos(base - A) * l1, k2y = hy + Math.sin(base - A) * l1;
    const o1 = (k1x - hx) * nx + (k1y - hy) * ny;
    const o2 = (k2x - hx) * nx + (k2y - hy) * ny;
    const kx = o1 > o2 ? k1x : k2x, ky = o1 > o2 ? k1y : k2y;
    const fx = hx + Math.cos(base) * dd, fy = hy + Math.sin(base) * dd;

    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(kx, ky); ctx.lineTo(fx, fy);
    ctx.lineWidth = 8.5 * S; ctx.strokeStyle = hsla(h, 60, 6); ctx.stroke();
    ctx.lineWidth = 5.4 * S; ctx.strokeStyle = hsla(h, 52, 24); ctx.stroke();

    ctx.fillStyle = hsla(h, 52, 22);
    ctx.beginPath(); ctx.arc(fx, fy, 4.6 * S, 0, TAU); ctx.fill();
    ctx.strokeStyle = BONE; ctx.lineWidth = 2 * S;
    for (let j = -1; j <= 1; j++) {
      const ang = base + j * 0.5;
      ctx.beginPath();
      ctx.moveTo(fx + Math.cos(ang) * 3 * S, fy + Math.sin(ang) * 3 * S);
      ctx.lineTo(fx + Math.cos(ang) * 10 * S, fy + Math.sin(ang) * 10 * S);
      ctx.stroke();
    }
  }

  function drawBody() {
    const h = theme.h;
    computeEdges();

    // soft ground shadow
    ctx.save();
    ctx.translate(12 * S, 20 * S);
    bodyPath();
    ctx.fillStyle = 'rgba(0,0,0,0.28)';
    ctx.fill();
    ctx.restore();

    for (const l of legs) drawLeg(l);

    // outline
    bodyPath();
    ctx.lineJoin = 'round';
    ctx.lineWidth = 3 * S;
    ctx.strokeStyle = hsla(h, 60, 6);
    ctx.stroke();

    // scale bands
    for (let i = N - 2; i >= 0; i--) {
      const t = i / N;
      const c = hsla(h + t * 28, 58, 20 + (1 - t) * 10 + (i % 4 < 2 ? 3 : 0));
      ctx.beginPath();
      ctx.moveTo(Lx[i], Ly[i]); ctx.lineTo(Lx[i + 1], Ly[i + 1]);
      ctx.lineTo(Rx[i + 1], Ry[i + 1]); ctx.lineTo(Rx[i], Ry[i]);
      ctx.closePath();
      ctx.fillStyle = c; ctx.strokeStyle = c; ctx.lineWidth = 1;
      ctx.fill(); ctx.stroke();
    }

    // rounded highlight down the back
    ctx.lineCap = 'round';
    for (let i = 0; i < N - 1; i++) {
      ctx.beginPath();
      ctx.moveTo(segs[i].x, segs[i].y);
      ctx.lineTo(segs[i + 1].x, segs[i + 1].y);
      ctx.lineWidth = rad[i] * 0.75;
      ctx.strokeStyle = hsla(h + (i / N) * 28, 55, 36, 0.32);
      ctx.stroke();
    }

    // scale chevrons
    ctx.lineWidth = 1;
    ctx.strokeStyle = hsla(h, 60, 62, 0.2);
    for (let i = 2; i < N - 1; i++) {
      const s = segs[i];
      ctx.beginPath();
      ctx.moveTo(Lx[i], Ly[i]);
      ctx.quadraticCurveTo(s.x - Math.cos(s.a) * rad[i] * 0.7, s.y - Math.sin(s.a) * rad[i] * 0.7, Rx[i], Ry[i]);
      ctx.stroke();
    }

    // tail spade
    const tl = segs[N - 1], back = tl.a + Math.PI;
    const dir = (a, d) => [Math.cos(a) * d, Math.sin(a) * d];
    const [bx, by] = dir(back, 8 * S);
    const [tx, ty] = dir(back, 32 * S);
    const [lx, ly] = dir(back - 0.95, 15 * S);
    const [rx, ry] = dir(back + 0.95, 15 * S);
    ctx.beginPath();
    ctx.moveTo(tl.x, tl.y);
    ctx.quadraticCurveTo(tl.x + lx + bx, tl.y + ly + by, tl.x + tx, tl.y + ty);
    ctx.quadraticCurveTo(tl.x + rx + bx, tl.y + ry + by, tl.x, tl.y);
    ctx.fillStyle = hsla(h, 62, 28, 0.95);
    ctx.strokeStyle = hsla(h, 60, 8);
    ctx.lineWidth = 1.6 * S;
    ctx.fill(); ctx.stroke();
  }

  function drawWing(side) {
    const h = theme.h;
    const sg = segs[WI], a = sg.a, f = flap;
    const sc = 1 - 0.42 * Math.max(0, f) - 0.1 * Math.max(0, -f);
    const r = rad[WI];
    const sx = sg.x + Math.cos(a + side * Math.PI / 2) * r * 0.35;
    const sy = sg.y + Math.sin(a + side * Math.PI / 2) * r * 0.35;
    const L1 = 72 * S * sc, L2 = 88 * S * sc, LF = 170 * S * sc;

    const th1 = a + side * (Math.PI / 2 + 0.7 + 0.22 * f);
    const ex = sx + Math.cos(th1) * L1, ey = sy + Math.sin(th1) * L1;
    const th2 = a + side * (Math.PI / 2 - 0.22 + 0.18 * f);
    const wx = ex + Math.cos(th2) * L2, wy = ey + Math.sin(th2) * L2;

    const lens = [1, 1, 0.88, 0.66];
    const tips = lens.map((ln, k) => {
      const th = a + side * (Math.PI / 2 - 0.02 + k * 0.44 + 0.08 * f);
      return [wx + Math.cos(th) * LF * ln, wy + Math.sin(th) * LF * ln];
    });
    const bs = segs[WI + 11], br = rad[WI + 11];
    const bx = bs.x + Math.cos(bs.a + side * Math.PI / 2) * br * 0.6;
    const by = bs.y + Math.sin(bs.a + side * Math.PI / 2) * br * 0.6;

    const scallop = (p, q, pull) => {
      const mx = (p[0] + q[0]) / 2, my = (p[1] + q[1]) / 2;
      ctx.quadraticCurveTo(mx + (wx - mx) * pull, my + (wy - my) * pull, q[0], q[1]);
    };

    // membrane
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.lineTo(ex, ey);
    ctx.lineTo(wx, wy);
    ctx.lineTo(tips[0][0], tips[0][1]);
    for (let k = 0; k < 3; k++) scallop(tips[k], tips[k + 1], 0.24);
    scallop(tips[3], [bx, by], 0.14);
    ctx.closePath();
    const g = ctx.createRadialGradient(wx, wy, 10, wx, wy, LF * 1.1);
    g.addColorStop(0, hsla(h, 65, 26, 0.92));
    g.addColorStop(1, hsla(h, 75, 42, 0.5));
    ctx.fillStyle = g;
    ctx.fill();
    ctx.lineJoin = 'round';
    ctx.lineWidth = 1.4;
    ctx.strokeStyle = hsla(h, 85, 68, 0.75);
    ctx.stroke();

    // finger bones
    ctx.lineCap = 'round';
    tips.forEach((p, k) => {
      ctx.beginPath(); ctx.moveTo(wx, wy); ctx.lineTo(p[0], p[1]);
      ctx.lineWidth = (3.2 - k * 0.5) * S; ctx.strokeStyle = hsla(h, 60, 12, 0.95); ctx.stroke();
    });
    // arm bones
    ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(ex, ey); ctx.lineTo(wx, wy);
    ctx.lineWidth = 6.4 * S; ctx.strokeStyle = hsla(h, 55, 10); ctx.stroke();
    ctx.lineWidth = 3.8 * S; ctx.strokeStyle = hsla(h, 50, 30); ctx.stroke();
    // wrist claw
    const cth = th2 - side * 0.9;
    ctx.beginPath(); ctx.moveTo(wx, wy);
    ctx.lineTo(wx + Math.cos(cth) * 16 * S, wy + Math.sin(cth) * 16 * S);
    ctx.lineWidth = 2.6 * S; ctx.strokeStyle = BONE; ctx.stroke();
    // shoulder
    ctx.fillStyle = hsla(h, 58, 26);
    ctx.beginPath(); ctx.arc(sx, sy, r * 0.5, 0, TAU); ctx.fill();
  }

  function drawSpines() {
    const h = theme.h;
    ctx.fillStyle = hsla(h + 10, 65, 62, 0.95);
    ctx.strokeStyle = hsla(h, 60, 10);
    ctx.lineWidth = 1;
    ctx.lineJoin = 'round';
    for (let i = 3; i < N - 3; i += 2) {
      const s = segs[i], sz = rad[i] * 0.6;
      const c = Math.cos(s.a), sn = Math.sin(s.a);
      ctx.beginPath();
      ctx.moveTo(s.x + c * sz * 0.8, s.y + sn * sz * 0.8);
      ctx.lineTo(s.x - sn * sz * 0.45, s.y + c * sz * 0.45);
      ctx.lineTo(s.x - c * sz * 1.5, s.y - sn * sz * 1.5);
      ctx.lineTo(s.x + sn * sz * 0.45, s.y - c * sz * 0.45);
      ctx.closePath();
      ctx.fill(); ctx.stroke();
    }
  }

  function drawHead(t) {
    const h = theme.h;
    const g = jaw * 6;
    const blink = (t % 5) < 0.13;
    ctx.save();
    ctx.translate(head.x, head.y);
    ctx.rotate(head.a);
    ctx.scale(S, S);
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';

    // cheek frills
    for (const k of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(10, k * 12); ctx.lineTo(4, k * 30); ctx.lineTo(0, k * 17);
      ctx.lineTo(-6, k * 35); ctx.lineTo(-9, k * 15); ctx.lineTo(-18, k * 28);
      ctx.lineTo(-14, k * 10); ctx.closePath();
      ctx.fillStyle = hsla(h, 62, 25, 0.95);
      ctx.strokeStyle = hsla(h, 60, 8);
      ctx.lineWidth = 1.5;
      ctx.fill(); ctx.stroke();
    }

    // horns
    for (const k of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(6, k * 9);
      ctx.quadraticCurveTo(-8, k * 20, -34, k * 26);
      ctx.quadraticCurveTo(-14, k * 13, -4, k * 5);
      ctx.closePath();
      ctx.fillStyle = BONE; ctx.strokeStyle = 'rgba(40,30,20,0.7)'; ctx.lineWidth = 1;
      ctx.fill(); ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(17, k * 10); ctx.lineTo(8, k * 23); ctx.lineTo(11, k * 9); ctx.closePath();
      ctx.fill(); ctx.stroke();
    }

    // cranium
    ctx.beginPath();
    ctx.moveTo(-12, -11); ctx.lineTo(-4, -14); ctx.lineTo(8, -15); ctx.lineTo(20, -11);
    ctx.lineTo(20, 11); ctx.lineTo(8, 15); ctx.lineTo(-4, 14); ctx.lineTo(-12, 11);
    ctx.closePath();
    ctx.fillStyle = hsla(h, 58, 27);
    ctx.strokeStyle = hsla(h, 60, 7);
    ctx.lineWidth = 2;
    ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(-10, 0); ctx.lineTo(22, 0);
    ctx.strokeStyle = hsla(h, 60, 62, 0.28); ctx.lineWidth = 3; ctx.stroke();

    // mouth glow
    if (g > 0.4) {
      ctx.shadowColor = 'hsl(28 100% 55%)';
      ctx.shadowBlur = 20 * jaw;
      ctx.beginPath();
      ctx.moveTo(16, -g - 1); ctx.lineTo(47, -g * 0.6); ctx.lineTo(47, g * 0.6); ctx.lineTo(16, g + 1);
      ctx.closePath();
      ctx.fillStyle = `hsl(26 100% ${50 + jaw * 22}%)`;
      ctx.fill();
      ctx.shadowBlur = 0;
    }

    // jaw halves + teeth
    for (const k of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(18, k * 11);
      ctx.lineTo(32, k * (8 + g * 0.5));
      ctx.lineTo(47, k * (3.2 + g));
      ctx.lineTo(47, k * (0.4 + g * 0.9));
      ctx.lineTo(18, k * (1 + g * 0.5));
      ctx.closePath();
      ctx.fillStyle = hsla(h, 58, 30);
      ctx.strokeStyle = hsla(h, 60, 7);
      ctx.lineWidth = 1.6;
      ctx.fill(); ctx.stroke();

      if (jaw > 0.2) {
        ctx.fillStyle = `rgba(250,246,232,${jaw})`;
        for (const x of [26, 34, 42]) {
          const yin = k * ((1 + g * 0.5) + ((x - 18) / 29) * ((0.4 + g * 0.9) - (1 + g * 0.5)));
          ctx.beginPath();
          ctx.moveTo(x - 2, yin); ctx.lineTo(x + 2, yin); ctx.lineTo(x, yin - k * 3.6 * jaw);
          ctx.closePath(); ctx.fill();
        }
      }
      // nostril
      ctx.fillStyle = 'rgba(0,0,0,0.75)';
      ctx.beginPath(); ctx.arc(42, k * (2.8 + g * 0.8), 1.1, 0, TAU); ctx.fill();
    }

    // eyes + brow ridges
    for (const k of [-1, 1]) {
      ctx.beginPath(); ctx.moveTo(5, k * 5.5); ctx.lineTo(21, k * 9);
      ctx.strokeStyle = hsla(h, 60, 6); ctx.lineWidth = 2.4; ctx.stroke();
      if (blink) {
        ctx.beginPath(); ctx.moveTo(10.5, k * 8.4); ctx.lineTo(16, k * 8.4);
        ctx.strokeStyle = hsla(h, 60, 6); ctx.lineWidth = 1.4; ctx.stroke();
      } else {
        ctx.shadowColor = theme.eye;
        ctx.shadowBlur = 10 + jaw * 12;
        ctx.fillStyle = theme.eye;
        ctx.beginPath(); ctx.arc(13, k * 8.2, 3.1 + jaw * 0.5, 0, TAU); ctx.fill();
        ctx.shadowBlur = 0;
        ctx.fillStyle = '#000';
        ctx.beginPath(); ctx.ellipse(13.4, k * 8.2, 0.8, 2.5, 0, 0, TAU); ctx.fill();
      }
    }
    ctx.restore();
  }

  function drawParticles(t) {
    ctx.globalCompositeOperation = 'lighter';
    for (const p of fire) {
      const u = p.age / p.life;
      const r = p.size * (1 + u * 1.8);
      ctx.globalAlpha = Math.pow(1 - u, 1.1) * 0.7;
      ctx.drawImage(SPRITES[Math.min(7, Math.floor(u * 8))], p.x - r, p.y - r, r * 2, r * 2);
    }
    ctx.globalAlpha = 1;
    for (const p of sparks) {
      const u = p.age / p.life;
      const tw = 0.6 + 0.4 * Math.sin(t * 30 + p.x);
      const a = (1 - u) * tw;
      ctx.fillStyle = p.tint ? hsla(p.hue, 90, 68, a) : hsla(p.hue, 100, 62 + (1 - u) * 20, a);
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size * (1 - u * 0.5), 0, TAU);
      ctx.fill();
    }
    ctx.globalCompositeOperation = 'source-over';
  }

  function render(t) {
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    ctx.globalCompositeOperation = 'source-over';
    ctx.globalAlpha = 1;
    ctx.drawImage(bg, 0, 0, W, H);
    drawStars(t);
    drawFireGlow();

    drawBody();
    if (opts.wings) { drawWing(-1); drawWing(1); }
    drawSpines();
    drawHead(t);
    drawParticles(t);
  }

  /* ------------------------------------------------------------------ *
   *  Boot
   * ------------------------------------------------------------------ */
  window.addEventListener('resize', resize);
  resize();
  pointer.x = W / 2;
  pointer.y = H / 2;

  let last = performance.now();
  function frame(now) {
    const dt = Math.min((now - last) / 1000, 0.05);
    last = now;
    time += dt;
    update(dt, time);
    render(time);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();
